---
title:  LIQUID_TAG_REGEX excerpt whitespace control test
layout: post
---

{%- assign xyzzy = 'You are in a maze of twisty little passages, all alike.' %}
{{- xyzzy -}}
